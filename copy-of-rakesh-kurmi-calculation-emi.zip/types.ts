
export enum CalculatorType {
  EMI = 'emi',
  SIP = 'sip',
  INTEREST = 'interest',
}
